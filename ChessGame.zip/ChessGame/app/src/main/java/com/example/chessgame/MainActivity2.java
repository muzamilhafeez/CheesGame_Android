package com.example.chessgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.chessgame.Pieces.pawns.darkpawn.pawnmethod;
import com.example.chessgame.databinding.ActivityMain2Binding;


public class MainActivity2 extends AppCompatActivity {
    ActivityMain2Binding Binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Binding= ActivityMain2Binding.inflate(getLayoutInflater());
        setContentView(Binding.getRoot());


//        Binding.L7H.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Binding.L7H.setImageResource(R.drawable.dark);
//                Binding.L6H.setImageResource(R.drawable.bp);
//            }
//        });



        getSupportActionBar().hide();
    }
    public void moveablePiece(View view){

        pawnmethod p= new pawnmethod();
        p.moveallpawn(view,Binding);





    }
}