package com.example.chessgame;

import android.view.MotionEvent;
import android.view.View;
import android.widget.GridLayout;

public class ChessPieceTouchListener implements View.OnTouchListener {
    private float startX, startY;
    private int lastAction;

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                // Save the start position of the touch
                startX = event.getX();
                startY = event.getY();
                lastAction = MotionEvent.ACTION_DOWN;
                break;
            case MotionEvent.ACTION_MOVE:
                // Move the chess piece view
                v.setX(v.getX() + event.getX() - startX);
                v.setY(v.getY() + event.getY() - startY);
                startX = event.getX();
                startY = event.getY();
                lastAction = MotionEvent.ACTION_MOVE;
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // Snap the chess piece view to the center of the square
                int squareSize = GridLayout.getDefaultSize(40,40);
                int squareX = (int) ((v.getX() + squareSize / 2) / squareSize);
                int squareY = (int) ((v.getY() + squareSize / 2) / squareSize);
                v.setX(squareX * squareSize);
                v.setY(squareY * squareSize);
                lastAction = event.getActionMasked();
                break;
        }
        return true;
    }


}
